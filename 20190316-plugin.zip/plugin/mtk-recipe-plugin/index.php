<?php
/*

@package mkt-recipe-plugin

     ===================================
          INDEX. PHP
     ===================================
*
*
*/

// Silence is golden.
